import { evaluate, cartTotals, type Product } from './health'

export type Level = 'empty' | 'safe' | 'caution' | 'over'
export type Limits = { sugar: number; carbs: number; sodium: number }

// One place that decides the cart status, used by BOTH the home monitor and the cart page.
export function assessCart(items: { qty: number; product: Product }[], conditions: string[], lim: Limits) {
  const t = cartTotals(items)
  const pct = {
    sugar: (t.sugar / Math.max(lim.sugar, 1)) * 100,
    carbs: (t.carbs / Math.max(lim.carbs, 1)) * 100,
    sodium: (t.sodium / Math.max(lim.sodium, 1)) * 100,
  }
  const verdicts = items.map(i => evaluate(i.product, conditions).verdict)
  const risky = items.filter((_, k) => verdicts[k] === 'avoid')
  const worst = Math.max(pct.sugar, pct.carbs, pct.sodium)
  const over: string[] = []
  if (pct.sugar > 100) over.push(`Added sugar ${+t.sugar.toFixed(1)}g / ${lim.sugar}g`)
  if (pct.carbs > 100) over.push(`Net carbs ${+t.carbs.toFixed(0)}g / ${lim.carbs}g`)
  if (pct.sodium > 100) over.push(`Sodium ${Math.round(t.sodium)}mg / ${lim.sodium}mg`)
  const level: Level = items.length === 0 ? 'empty'
    : risky.length > 0 || worst > 100 ? 'over'
    : worst > 70 || verdicts.includes('caution') ? 'caution' : 'safe'
  return { t, pct, risky, over, level }
}
