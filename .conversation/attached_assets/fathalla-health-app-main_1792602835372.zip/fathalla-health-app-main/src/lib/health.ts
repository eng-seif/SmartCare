export type Product = {
  id: string; barcode: string | null; title: string; category: string | null
  price: number; image_url: string | null
  glycemic_index: number | null; glycemic_load: number | null; sugar_content: number | null
  net_carbs: number | null; sodium_content: number | null; health_score: number | null
  is_gluten_free: boolean | null; is_lactose_free: boolean | null; sat_fat_g?: number | null; serving_size?: string | null
}
export const n = (v: number | null | undefined) => Number(v ?? 0)
export type Verdict = 'safe' | 'caution' | 'avoid'

export const CONDITIONS: Record<string, string> = {
  t2d: 'Type 2 Diabetes', t1d: 'Type 1 Diabetes', prediabetes: 'Prediabetes / Insulin Resistance',
  hypertension: 'Hypertension', cardio: 'Cardiovascular / Cholesterol', lactose: 'Lactose Intolerance', celiac: 'Celiac / Gluten Sensitivity',
}

export function evaluate(p: Product, c: string[] = []) {
  const reasons: string[] = []
  let v = 'safe' as Verdict
  const up = (to: Verdict, why: string) => {
    reasons.push(why)
    if (to === 'avoid' || v === 'safe') v = to
  }
  if (c.some(x => ['t2d', 't1d', 'prediabetes'].includes(x))) {
    if (n(p.glycemic_index) > 55) up('avoid', `High glycemic index (${n(p.glycemic_index)})`)
    else if (n(p.glycemic_index) > 35) up('caution', `Moderate glycemic index (${n(p.glycemic_index)})`)
    if (n(p.sugar_content) > 10) up('avoid', `Added sugar ${n(p.sugar_content)}g`)
    else if (n(p.sugar_content) > 3) up('caution', `Added sugar ${n(p.sugar_content)}g`)
  }
  if (c.includes('hypertension') && n(p.sodium_content) > 400) up('avoid', `High sodium (${n(p.sodium_content)}mg)`)
  if (c.includes('cardio') && n(p.sat_fat_g) > 5) up('caution', `Saturated fat ${n(p.sat_fat_g)}g`)
  if (c.includes('lactose') && p.is_lactose_free === false) up('avoid', 'Contains lactose')
  if (c.includes('celiac') && p.is_gluten_free === false) up('avoid', 'Contains gluten')
  return { verdict: v, reasons }
}

export const cartTotals = (items: { qty: number; product: Product }[]) => ({
  sugar: items.reduce((s, i) => s + i.qty * n(i.product.sugar_content), 0),
  carbs: items.reduce((s, i) => s + i.qty * n(i.product.net_carbs), 0),
  sodium: items.reduce((s, i) => s + i.qty * n(i.product.sodium_content), 0),
  price: items.reduce((s, i) => s + i.qty * i.product.price, 0),
})
