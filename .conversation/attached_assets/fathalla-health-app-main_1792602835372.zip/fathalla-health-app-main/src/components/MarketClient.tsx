'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { supabaseBrowser } from '@/lib/supabase/client'
import { evaluate, n, type Product } from '@/lib/health'

    export default function MarketClient({ rows, conditions, monitor }: { rows: Product[]; conditions: string[]; monitor: { loggedIn: boolean; level: "empty" | "safe" | "caution" | "over"; unsafe: number; items: number; rows: { label: string; value: number; max: number; unit: string }[] } }) {
      const [diabeticOnly, setDiabeticOnly] = useState(true);
      const [activeCategory, setActiveCategory] = useState("All");
      const router = useRouter();
      const [toast, setToast] = useState<string | null>(null);
      async function addToCart(id: string, title: string) {
        const sb = supabaseBrowser();
        const { data: { user } } = await sb.auth.getUser();
        if (!user) { router.push("/register"); return; }
        const { data: row } = await sb.from("cart_items").select("qty").eq("product_id", id).maybeSingle();
        const { error } = await sb.from("cart_items").upsert(
          { user_id: user.id, product_id: id, qty: (row?.qty ?? 0) + 1 }, { onConflict: "user_id,product_id" });
        if (error) { console.error(error); setToast(`Could not add to cart: ${error.message}`); setTimeout(() => setToast(null), 6000); return; }
        setToast(`Added "${title}" to your smart cart`);
        setTimeout(() => setToast(null), 3000);
        router.refresh();
      }

      const level = monitor.loggedIn ? monitor.level : "empty";
      const m = {
        empty: { chip: "bg-surface-container-high text-on-surface-variant", dot: "bg-outline", text: "text-on-surface-variant", badge: "EMPTY", title: monitor.loggedIn ? "Cart is Empty" : "Sign in to Monitor", note: "ADD ITEMS" },
        safe: { chip: "bg-tertiary-fixed text-on-tertiary-fixed", dot: "bg-tertiary", text: "text-tertiary", badge: "SAFE", title: "Safe Response", note: "NO SPIKE RISK" },
        caution: { chip: "bg-primary-fixed text-on-primary-fixed-variant", dot: "bg-primary", text: "text-primary", badge: "CAUTION", title: "Approaching Limit", note: "NEAR LIMIT" },
        over: { chip: "bg-error-container text-on-error-container", dot: "bg-error", text: "text-error", badge: "RISK", title: "Spike Risk", note: monitor.unsafe > 0 ? `${monitor.unsafe} UNSAFE ITEM${monitor.unsafe > 1 ? "S" : ""}` : "OVER LIMIT" }
      }[level];
      const BADGE = {
        safe: "bg-tertiary-fixed text-on-tertiary-fixed",
        caution: "bg-primary-fixed text-on-primary-fixed-variant",
        avoid: "bg-error-container text-on-error-container"
      };
      const products = rows.map(r => {
        const v = evaluate(r, conditions).verdict;
        return {
          id: r.id, name: r.title, detail: r.category ?? "", price: Number(r.price).toFixed(2),
          tag: v === "safe" ? (n(r.sugar_content) === 0 ? "0% Added Sugar" : "Diabetic Safe") : v === "caution" ? "Use Caution" : "Not Recommended",
          badge: BADGE[v], gi: `GI: ${n(r.glycemic_index)}`, img: r.image_url || undefined,
          category: r.category ?? "", diabeticSafe: v === "safe"
        };
      });
      const categories = ["All", ...Array.from(new Set(products.map(p => p.category).filter(Boolean)))];
      const filteredProducts = products.filter(p =>
        (!diabeticOnly || p.diabeticSafe) && (activeCategory === "All" || p.category === activeCategory));
      return (
        <div className="flex flex-col w-full">
          {toast && <div className="fixed top-24 right-6 bg-inverse-surface text-inverse-on-surface px-4 py-3 rounded-lg shadow-xl z-50 font-title-md text-sm">{toast}</div>}
          {/* Top Intro & Hero Zone */}
          <section className="w-full bg-surface-container-lowest shadow-sm border-b border-surface-variant/40">
            <div className="max-w-[1440px] mx-auto px-4 md:px-margin-tablet lg:px-margin-desktop py-space-xl">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-space-xl items-center">
                {/* Left Content */}
                <div className="lg:col-span-7 flex flex-col gap-space-md">
                  <div className="inline-flex items-center gap-space-xs px-space-md py-1 rounded-full bg-tertiary/10 text-tertiary w-fit">
                    <span className="material-symbols-outlined text-base">verified</span>
                    <span className="font-label-md text-label-md font-bold tracking-wide uppercase">Built for Diabetic &amp; Chronic-Condition Shoppers</span>
                  </div>
                  <h1 className="font-headline-xl text-headline-xl text-on-surface tracking-tight leading-tight">
                    Simple &amp; Healthy Grocery Shopping at Fathalla
                  </h1>
                  <p className="font-body-lg text-body-lg text-on-surface-variant max-w-2xl leading-relaxed">
                    Every product shows its glycemic index, added sugar, net carbs and sodium, and is matched against your own health profile so you can shop with confidence.
                  </p>
                  <div className="flex flex-wrap items-center gap-space-md pt-space-xs">
                    <button 
                      onClick={() => router.push("/scanner")}
                      className="inline-flex items-center gap-space-sm px-space-lg py-space-md bg-primary-container hover:bg-primary-container/90 text-on-secondary rounded-xl font-title-md text-title-md transition-all shadow-md active:scale-95 group" 
                      type="button"
                    >
                      <span className="material-symbols-outlined text-2xl group-hover:rotate-12 transition-transform">barcode_scanner</span>
                      <span>Scan Barcode In-Store</span>
                    </button>
                    <div className="flex items-center gap-space-sm px-space-md py-space-sm rounded-xl bg-surface-container-low border border-surface-variant/60 text-on-surface">
                      <span className="material-symbols-outlined text-tertiary text-2xl">support_agent</span>
                      <div className="flex flex-col">
                        <span className="font-label-sm text-label-sm text-on-surface-variant">Medical Disclaimer</span>
                        <span className="font-title-md text-title-md font-bold text-on-surface">Ask your doctor</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right: Live Health Monitor (real cart data) */}
                <div className="lg:col-span-5">
                  <div className="bg-surface-container-lowest border-2 border-surface-container-high rounded-xl p-space-lg shadow-sm flex flex-col gap-space-md relative overflow-hidden">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-space-sm">
                        <div className="w-11 h-11 rounded-xl bg-tertiary/10 flex items-center justify-center text-tertiary">
                          <span className="material-symbols-outlined text-2xl">vital_signs</span>
                        </div>
                        <div>
                          <span className="font-label-sm text-label-sm text-on-surface-variant block uppercase tracking-wider font-semibold">Live Health Monitor</span>
                          <span className="font-title-md text-title-md text-on-surface font-bold">Current Cart Glycemic Status</span>
                        </div>
                      </div>
                      <span className={`px-space-sm py-0.5 rounded-full ${m.chip} font-metric-label text-metric-label uppercase font-bold flex items-center gap-1`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${m.dot}`}></span> {m.badge}
                      </span>
                    </div>

                    <div className="flex flex-col gap-space-sm bg-surface-container-low p-space-md rounded-xl border border-surface-variant/40">
                      <span className={`font-headline-sm text-headline-sm font-bold flex items-center gap-1.5 ${m.text}`}>
                        <span className={`w-2.5 h-2.5 rounded-full animate-pulse ${m.dot}`}></span>{m.title}
                      </span>
                      {monitor.rows.map(r => {
                        const pct = Math.min(100, (r.value / Math.max(r.max, 1)) * 100);
                        const over = r.value > r.max;
                        return (
                          <div key={r.label} className="flex flex-col gap-1">
                            <div className="flex justify-between font-label-md text-label-md text-on-surface-variant">
                              <span>{r.label}</span>
                              <span className={over ? "text-error font-bold" : "text-on-surface font-semibold"}>{+r.value.toFixed(1)} / {r.max}{r.unit}</span>
                            </div>
                            <div className="w-full h-2 rounded-full bg-surface-container-highest overflow-hidden">
                              <div className={`h-full rounded-full transition-all duration-500 ${over ? "bg-error" : pct > 70 ? "bg-primary-container" : "bg-tertiary"}`} style={{ width: `${pct}%` }}></div>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    <Link href={monitor.loggedIn ? "/cart" : "/register"} className="bg-surface-container-lowest border border-surface-variant/60 rounded-xl p-space-md flex items-center justify-between hover:bg-surface-container-low transition-colors">
                      <div className="flex items-center gap-space-sm">
                        <span className="material-symbols-outlined text-primary-container text-xl">shopping_cart</span>
                        <span className="font-body-md text-body-md text-on-surface font-semibold">{monitor.items} {monitor.items === 1 ? "Item" : "Items"} in Your Smart Cart</span>
                      </div>
                      <span className={`font-metric-label text-metric-label font-bold tracking-wide px-space-xs py-0.5 rounded ${m.chip}`}>{m.note}</span>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Filter & Quick Action Toolbar */}
          <section className="w-full bg-surface sticky top-20 z-40 shadow-sm backdrop-blur-md bg-surface/95 border-b border-surface-variant/40">
            <div className="max-w-[1440px] mx-auto px-4 md:px-margin-tablet lg:px-margin-desktop py-space-md">
              <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-space-md">
                {/* Category Pills */}
                <div className="flex items-center gap-space-xs overflow-x-auto pb-1 lg:pb-0 scrollbar-none">
                  {categories.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setActiveCategory(cat)}
                      className={`px-space-md py-space-sm rounded-full font-title-md text-title-md whitespace-nowrap transition-colors border ${
                        activeCategory === cat 
                          ? 'bg-inverse-surface text-inverse-on-surface border-inverse-surface shadow-sm'
                          : 'bg-surface-container-lowest text-on-surface-variant hover:text-on-surface hover:bg-surface-container-low border-surface-variant/60'
                      }`}
                      type="button"
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                {/* Safe Filter Switch */}
                <div className="flex items-center justify-between sm:justify-end gap-space-md bg-surface-container-low px-space-md py-space-xs rounded-xl border border-surface-variant/60 shadow-sm shrink-0">
                  <div className="flex flex-col">
                    <span className="font-title-md text-title-md font-bold text-on-surface leading-tight flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-tertiary"></span> Diabetic Safe Only
                    </span>
                    <span className="font-body-sm text-body-sm text-on-surface-variant">Hide high-GI groceries</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      checked={diabeticOnly} 
                      onChange={(e) => setDiabeticOnly(e.target.checked)} 
                      className="sr-only peer" 
                      type="checkbox"
                    />
                    <div className="w-14 h-8 bg-surface-dim peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[4px] after:left-[4px] after:bg-white after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-tertiary shadow-inner"></div>
                  </label>
                </div>
              </div>
            </div>
          </section>

          {/* Curated Product Catalog Section */}
          <section className="w-full py-space-xl">
            <div className="max-w-[1440px] mx-auto px-4 md:px-margin-tablet lg:px-margin-desktop flex flex-col gap-space-lg">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm">
                <div>
                  <h2 className="font-headline-lg text-headline-lg text-on-surface tracking-tight font-bold">Health-Aware Groceries</h2>
                  <p className="font-body-md text-body-md text-on-surface-variant pt-0.5">Every item is rated against your health profile</p>
                </div>
                <span className="inline-flex items-center gap-1.5 font-label-md text-label-md text-on-surface-variant bg-surface-container-high px-space-md py-1 rounded-full w-fit border border-surface-variant/40">
                  <span className="w-2 h-2 rounded-full bg-tertiary"></span>
                  Showing {filteredProducts.length} of {products.length} Foods
                </span>
              </div>

              {/* 4 Columns Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-space-lg">
                {filteredProducts.map(p => (
                  <article key={p.id} className="bg-surface-container-lowest rounded-xl border border-surface-variant/60 shadow-sm hover:shadow-md hover:border-primary/40 transition-all flex flex-col overflow-hidden group">
                    <Link href={`/product/${p.id}`} className="relative w-full h-52 bg-surface-container-low overflow-hidden block">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" src={p.img} alt={p.name} />
                      <div className="absolute top-space-sm left-space-sm">
                        <span className={`inline-flex items-center gap-1 px-space-sm py-1 rounded-full ${p.badge} font-label-sm text-label-sm font-bold shadow-sm backdrop-blur-sm`}>
                          <span className="w-1.5 h-1.5 rounded-full bg-tertiary"></span>
                          {p.tag}
                        </span>
                      </div>
                      <div className="absolute bottom-space-xs right-space-xs bg-surface-container-lowest/95 backdrop-blur-sm px-space-xs py-0.5 rounded font-metric-label text-metric-label text-on-surface font-bold border border-surface-variant/60 shadow-sm">
                        {p.gi}
                      </div>
                    </Link>
                    <div className="p-space-md flex-1 flex flex-col justify-between gap-space-md">
                      <div>
                        <Link href={`/product/${p.id}`}>
                          <h3 className="font-title-lg text-title-lg text-on-surface font-bold leading-snug group-hover:text-primary transition-colors">{p.name}</h3>
                        </Link>
                        <p className="font-body-md text-body-md text-on-surface-variant pt-0.5">{p.detail}</p>
                      </div>
                      <div className="flex items-center justify-between pt-space-xs border-t border-surface-variant/30">
                        <div className="flex flex-col">
                          <span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Price</span>
                          <span className="font-metric-display text-metric-display text-on-surface font-bold">{p.price} <span className="font-body-sm text-body-sm font-normal text-on-surface-variant">EGP</span></span>
                        </div>
                        <button 
                          onClick={() => addToCart(p.id, p.name)}
                          className="h-11 px-space-md bg-primary-container hover:bg-primary-container/90 text-on-secondary rounded-lg font-title-md text-title-md flex items-center gap-space-xs active:scale-95 transition-all shadow-sm" 
                          type="button"
                        >
                          <span className="material-symbols-outlined text-xl">add_shopping_cart</span>
                          <span>Add</span>
                        </button>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          </section>

          {/* Bottom Value Proposition Cards */}
          <section className="w-full bg-surface-container-low/70 py-space-xl border-t border-surface-variant/50">
            <div className="max-w-[1440px] mx-auto px-4 md:px-margin-tablet lg:px-margin-desktop">
              <div className="text-center max-w-xl mx-auto mb-space-lg">
                <h2 className="font-headline-lg text-headline-lg text-on-surface font-bold tracking-tight">How We Rate Every Product</h2>
                <p className="font-body-md text-body-md text-on-surface-variant pt-1">Simple, transparent rules based on published nutrition guidance.</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-space-lg">
                <div className="bg-surface-container-lowest p-space-lg rounded-xl border border-surface-variant/60 shadow-sm flex flex-col gap-space-sm items-start hover:shadow-md transition-shadow">
                  <div className="w-12 h-12 rounded-xl bg-tertiary/10 text-tertiary flex items-center justify-center">
                    <span className="material-symbols-outlined text-3xl">science</span>
                  </div>
                  <h3 className="font-headline-sm text-headline-sm text-on-surface font-bold">Transparent Nutrition Data</h3>
                  <p className="font-body-md text-body-md text-on-surface-variant leading-relaxed">
                    Values come from product labels and published glycemic index tables, and are shown per serving.
                  </p>
                  <div className="mt-auto pt-space-md flex items-center gap-1.5 text-tertiary font-title-md text-title-md font-semibold">
                    <span>Per-serving values</span>
                    <span className="material-symbols-outlined text-xl">check_circle</span>
                  </div>
                </div>
                <div className="bg-surface-container-lowest p-space-lg rounded-xl border border-surface-variant/60 shadow-sm flex flex-col gap-space-sm items-start hover:shadow-md transition-shadow">
                  <div className="w-12 h-12 rounded-xl bg-primary-container/10 text-primary-container flex items-center justify-center">
                    <span className="material-symbols-outlined text-3xl">ssid_chart</span>
                  </div>
                  <h3 className="font-headline-sm text-headline-sm text-on-surface font-bold">Glycemic Index &amp; Load</h3>
                  <p className="font-body-md text-body-md text-on-surface-variant leading-relaxed">
                    Glycemic index and load help you spot foods that raise blood sugar quickly, so you can pick steadier options.
                  </p>
                  <div className="mt-auto pt-space-md flex items-center gap-1.5 text-primary-container font-title-md text-title-md font-semibold">
                    <span>Know Your Spikes</span>
                    <span className="material-symbols-outlined text-xl">health_and_safety</span>
                  </div>
                </div>
                <div className="bg-surface-container-lowest p-space-lg rounded-xl border border-surface-variant/60 shadow-sm flex flex-col gap-space-sm items-start hover:shadow-md transition-shadow">
                  <div className="w-12 h-12 rounded-xl bg-secondary-fixed-dim/30 text-on-surface flex items-center justify-center">
                    <span className="material-symbols-outlined text-3xl">qr_code_scanner</span>
                  </div>
                  <h3 className="font-headline-sm text-headline-sm text-on-surface font-bold">In-Branch Smart Scan</h3>
                  <p className="font-body-md text-body-md text-on-surface-variant leading-relaxed">
                    Use your phone's camera in any Fathalla aisle to scan physical packaging barcodes for an instantaneous glycemic green light and safe swap suggestions.
                  </p>
                  <div className="mt-auto pt-space-md flex items-center gap-1.5 text-on-surface font-title-md text-title-md font-semibold">
                    <span>Works with any catalog barcode</span>
                    <span className="material-symbols-outlined text-xl">storefront</span>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      );
    }

