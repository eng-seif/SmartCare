import { supabaseServer } from '@/lib/supabase/server'
import MarketClient from '@/components/MarketClient'
import { type Product } from '@/lib/health'
import { assessCart } from '@/lib/cart-status'

export default async function Home() {
  const sb = await supabaseServer()
  const { data: { user } } = await sb.auth.getUser()
  const { data: profile } = user ? await sb.from('profiles').select('conditions, max_sugar_g, max_carbs_g, max_sodium_mg').eq('id', user.id).maybeSingle() : { data: null }
  const conditions: string[] = profile?.conditions ?? []
  const lim = { sugar: Number(profile?.max_sugar_g ?? 15), carbs: Number(profile?.max_carbs_g ?? 50), sodium: Number(profile?.max_sodium_mg ?? 1500) }
  const { data: rows } = await sb.from('products').select('*').order('title')
  const { data: cart } = user ? await sb.from('cart_items').select('qty, product:products(*)') : { data: [] }
  const items: { qty: number; product: Product }[] = (cart ?? []).map((r: any) => ({ qty: r.qty, product: r.product })).filter((i: any) => i.product)
  const a = assessCart(items, conditions, lim)
  const monitor = {
    loggedIn: !!user, level: a.level, unsafe: a.risky.length, items: items.reduce((s, i) => s + i.qty, 0),
    rows: [
      { label: 'Added sugar', value: a.t.sugar, max: lim.sugar, unit: 'g' },
      { label: 'Net carbs', value: a.t.carbs, max: lim.carbs, unit: 'g' },
      { label: 'Sodium', value: a.t.sodium, max: lim.sodium, unit: 'mg' },
    ],
  }
  return <MarketClient rows={(rows ?? []) as Product[]} conditions={conditions} monitor={monitor} />
}
