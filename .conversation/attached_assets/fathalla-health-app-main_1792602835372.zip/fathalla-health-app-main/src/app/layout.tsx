import './globals.css'
import { Inter, JetBrains_Mono, Cairo } from 'next/font/google'
import { cookies } from 'next/headers'
import Translator from '@/components/Translator'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import MobileNav from '../components/MobileNav'
import LiveRefresh from '@/components/LiveRefresh'
import { supabaseServer } from '@/lib/supabase/server'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter', weight: ['400', '500', '600', '700'] })
const cairo = Cairo({ subsets: ['arabic', 'latin'], variable: '--font-cairo', weight: ['400', '500', '600', '700'] })
const mono = JetBrains_Mono({ subsets: ['latin'], variable: '--font-mono-jb', weight: ['600', '700'] })
export const metadata = { title: 'Fathalla Healthy Market - Clinical Glycemic Nutrition' }

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const lang: 'en' | 'ar' = (await cookies()).get('lang')?.value === 'ar' ? 'ar' : 'en'
  const sb = await supabaseServer()
  const { data: { user } } = await sb.auth.getUser()
  const { data: prof } = user ? await sb.from('profiles').select('full_name').eq('id', user.id).maybeSingle() : { data: null }
  const { data: cart } = user ? await sb.from('cart_items').select('qty') : { data: [] }
  const cartCount = (cart ?? []).reduce((s: number, r: { qty: number }) => s + r.qty, 0)
  return (
    <html lang={lang} dir={lang === 'ar' ? 'rtl' : 'ltr'} className={`${inter.variable} ${mono.variable} ${cairo.variable}`}>
      <head>
        <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
        {lang === 'ar' && <style dangerouslySetInnerHTML={{ __html: 'body{opacity:0}' }} />}
        {lang === 'ar' && <script dangerouslySetInnerHTML={{ __html: 'setTimeout(function(){document.body&&(document.body.style.opacity=1)},2500)' }} />}
      </head>
      <body className="bg-surface font-body-md text-body-md text-on-surface antialiased">
        <Translator lang={lang} />
        <div className="min-h-screen flex flex-col bg-surface">
          {user && <LiveRefresh userId={user.id} />}
          <Header lang={lang} cartCount={cartCount} user={user ? { name: prof?.full_name ?? '', email: user.email ?? '' } : null} />
          <main className="w-full pt-20 pb-16 lg:pb-0 bg-surface flex-1">{children}</main>
          <Footer />
          <MobileNav cartCount={cartCount} loggedIn={!!user} />
        </div>
      </body>
    </html>
  )
}
