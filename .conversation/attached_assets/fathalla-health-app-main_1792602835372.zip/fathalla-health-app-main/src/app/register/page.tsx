import { redirect } from 'next/navigation'
import { supabaseServer } from '@/lib/supabase/server'
import RegisterForm from '@/components/RegisterForm'

export default async function Page() {
  const sb = await supabaseServer()
  const { data: { user } } = await sb.auth.getUser()
  if (user) redirect('/') // already signed in: hide register / login
  return <RegisterForm />
}
