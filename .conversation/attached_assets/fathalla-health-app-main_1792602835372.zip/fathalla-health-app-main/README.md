# Setup
1. npm i @supabase/supabase-js @supabase/ssr
2. .env.local -> NEXT_PUBLIC_SUPABASE_URL / NEXT_PUBLIC_SUPABASE_ANON_KEY
3. Run supabase/schema.sql in the Supabase SQL editor
4. Copy these folders into your Next.js project (App Router, Tailwind, `@/*` alias)
5. Supabase > Auth: disable "Confirm email" while developing
